import {Text, StyleSheet, View, ScrollView} from 'react-native';
import {useState} from "react";
import CardLivro from "../components/CardLivro";
export default function Home() {
    const[livros, setLivros] = useState([])

    function buscarLivros() {
        var url =  "https://apps-api-livros.ucxocw.easypanel.host/livros"


        var retorno = await fetch(url, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
            }
        })


        retorno = await retorno.json()

    }

    return (
        <View>
            <Text>Books</Text>



            <ScrollView>
                {livros.map(function (livro) {
                    return <CardLivro livro={livro}/>
                })}
            </ScrollView>
        </View>
    )
}