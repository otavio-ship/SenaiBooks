import React from "react";
import { View, Text, StyleSheet } from "react-native";

export default function CardLivros({ nome, autor, preco }) {
    return (
        <View style={styles.card}>

            <View style={styles.capa}>
                <Text style={styles.capaTexto}>
                    {nome}
                </Text>
            </View>

            <Text style={styles.nome}>
                {nome}
            </Text>

            <Text style={styles.autor}>
                {autor}
            </Text>

            <Text style={styles.preco}>
                {preco}
            </Text>

            <TouchableOpacity style={styles.botao}>
                <Text style={styles.botaoTexto}>
                    Ver detalhes
                </Text>
            </TouchableOpacity>

        </View>
    );
}

const styles = StyleSheet.create({
    card: {
        width: 150,
        backgroundColor: "#fff",
        borderRadius: 10,
        marginRight: 10,
        paddingBottom: 15,
        elevation: 3,
    },

    capa: {
        height: 190,
        backgroundColor: "#1759c7",
        justifyContent: "center",
        alignItems: "center",
        padding: 10,
    },

    capaTexto: {
        color: "#fff",
        fontSize: 18,
        fontWeight: "bold",
        textAlign: "center",
    },

    nome: {
        fontSize: 16,
        fontWeight: "bold",
        margin: 10,
    },

    autor: {
        color: "#777",
        marginHorizontal: 10,
    },

    preco: {
        color: "#1759c7",
        fontSize: 18,
        fontWeight: "bold",
        margin: 10,
    },

    botao: {
        borderWidth: 1,
        borderColor: "#1759c7",
        borderRadius: 8,
        padding: 8,
        marginHorizontal: 10,
    },

    botaoTexto: {
        color: "#1759c7",
        textAlign: "center",
        fontWeight: "bold",
    },
});