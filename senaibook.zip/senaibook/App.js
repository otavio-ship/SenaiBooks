import React, { useState } from "react";

import {
  View,
  Text,
  TextInput,
  ScrollView,
  StyleSheet,
} from "react-native";

import CardLivros from "./components/CardLivro";

export default function App() {

  const [pesquisa, setPesquisa] = useState("");

  const livros = [
    {
      id: 1,
      nome: "Inteligência Artificial",
      autor: "Luiz Henrique Silva",
      preco: "R$ 89,90",
    },
    {
      id: 2,
      nome: "O Poder da Ação",
      autor: "Paulo Vieira",
      preco: "R$ 49,90",
    },
    {
      id: 3,
      nome: "Mindset",
      autor: "Carol S. Dweck",
      preco: "R$ 59,90",
    },
  ];

  return (
      <ScrollView style={styles.container}>

        <Text style={styles.logo}>
          SENAI Book
        </Text>

        <Text style={styles.titulo}>
          Encontre seu próximo livro
        </Text>

        <TextInput
            style={styles.input}
            placeholder="Buscar livros..."
            value={pesquisa}
            onChangeText={setPesquisa}
        />

        <Text style={styles.subtitulo}>
          Livros em destaque
        </Text>

        <ScrollView horizontal>

          {livros.map((livro) => (
              <CardLivros
                  key={livro.id}
                  nome={livro.nome}
                  autor={livro.autor}
                  preco={livro.preco}
              />
          ))}

        </ScrollView>

      </ScrollView>
  );
}

const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: "#fff",
    padding: 20,
  },

  logo: {
    fontSize: 32,
    fontWeight: "bold",
    color: "#1759c7",
    marginTop: 40,
  },

  titulo: {
    fontSize: 28,
    fontWeight: "bold",
    marginTop: 20,
  },

  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    padding: 15,
    marginTop: 20,
    marginBottom: 30,
  },

  subtitulo: {
    fontSize: 22,
    fontWeight: "bold",
    marginBottom: 20,
  },

});